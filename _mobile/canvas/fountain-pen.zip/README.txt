A Pen created at CodePen.io. You can find this one at http://codepen.io/timbrock/pen/rLoKAb.

 Fountain of dots based on the physics of projectile motion.