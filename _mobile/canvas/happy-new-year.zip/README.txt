A Pen created at CodePen.io. You can find this one at http://codepen.io/zystvan/pen/LEbNRp.

 Just a slightly modified version of [this](http://www.codecademy.com/MrMKenyon/codebits/Lv89kH)

You can also click to have fireworks appear where you clicked. 