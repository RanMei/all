A Pen created at CodePen.io. You can find this one at http://codepen.io/wbarlow/pen/NqLWXJ.

 working on a responsive app display based on [this dribble](https://dribbble.com/shots/1916308-Interactive-Bar-App/attachments/328747). i fell in love with the dribble's use of colors and gradients and i fear i won't be able to do the original artist justice, but i'll try my best.

animations should look like this:

![animations](http://i.imgur.com/ZQ1f81W.gif)

oh god i just saw what this looks like in IE and it is a hot mess. i'll fix that if i have time.