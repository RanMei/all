A Pen created at CodePen.io. You can find this one at http://codepen.io/samdbeckham/pen/OPXPNp.

 I recreated the parallax header on the [Firewatch](http://www.firewatchgame.com/) website in CSS. It was originally meant as a daft experiment but it seems to have blown-up.

I've base-64 encoded the images to avoid hot-linking to the Firewatch site.